/*Construa um “pipeline”. Crie um programa que conecte 4 processos através de 3 pipes. Utilize fork() para criar vários processos. Mande uma mensagem do quarto processo e faça a mensagem viajar pelos pipes  até chegar no primeiro processo, e exiba a mensagem.*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <wait.h>

int main()
{

    // Onde a mensagem sera enviada
    char Buf[1024];

    // Criando os pipes, as pontes com 2 posições
    //[0] = ler [1] = escrever
    int pp1[2];
    pipe(pp1);

    int pp2[2];
    pipe(pp2);

    int pp3[2];
    pipe(pp3);

    int pid;

    // 1
    pid = fork();

    /*
    if(pid == 0){
        Filho
    }else{
        Pai
    }
    */

    if (pid == 0)
    {

        printf("Sou o processo bisneto\n");
        read(pp3[0], Buf, 1024);
        write(pp2[1], Buf, 6);
    }
    else
    {
        // 2
        pid = fork();

        if (pid == 0)
        {
            printf("Sou o processo neto\n");
            read(pp2[0], Buf, 1024);
            write(pp1[1], Buf, 6);
        }
        // 3
        else
        {
            // 4
            pid = fork();

            if (pid == 0)
            {
                printf("Sou o processo pai\n");
                read(pp1[0], Buf, 1024);
                printf("Mensagem recebida do bisneto: %s", Buf);
            }
            else
            {
                printf("Sou o processo filho\n");
                write(pp3[1], "Ola \n", 6); // write(vetor, mensgem, tamanho da mensagem)
            }
        }
    }

    return 0;
}
