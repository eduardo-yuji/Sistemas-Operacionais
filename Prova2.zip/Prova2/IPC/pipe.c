#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<wait.h>

int main(){


    int pp[2];
    pipe(pp);
    int pid;
    pid = fork();

    char Buf[1024];

    int teste = 0;

    if( pid == 0 ){
        
        write(pp[1],"Ola \n", 6);

    }else{
        read(pp[0],Buf, 1024);
        printf("Mensagem recebida do filho: %s", Buf);
    }

    return 0;
}