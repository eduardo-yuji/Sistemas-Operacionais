/*
Projete um programa de cópia de arquivos chamado FileCopy usando pipes comuns. Esse programa receberá dois parâmetros: o primeiro é o nome do arquivo a ser
copiado e o segundo é o nome do arquivo copiado. Em seguida, o programa criará um pipe comum e gravará nele todo conteúdo do arquivo de uma só vez.
O processo filho lerá o conteúdo do pipe e o gravará no arquivo de destino. Por exemplo, se chamarmos o programa como descrito a seguir:

$ FileCopy entrada.txt copia.txt
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

    char *entrada = argv[1];
    char *saida = argv[2];

    FILE *entrada = fopen(entrada, "r");
    if (entrada == NULL)
    {
        perror("Erro ao abrir o arquivo de origem");
        exit(EXIT_FAILURE);
    }

    FILE *saida = fopen(saida, "w");
    if (saida == NULL)
    {
        perror("Erro ao abrir o arquivo de destino");
        fclose(entrada);
        exit(EXIT_FAILURE);
    }

    char Buf[1024];

    int pp1[2];
    pipe(pp1);

    int pid = fork();

    if (pid == 0)
    {
        printf("Sou o processo filho\n");
    }
    else
    {
        printf("Sou o processo pai\n");
    }

    return 0;
}