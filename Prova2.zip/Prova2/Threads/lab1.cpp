#include <iostream>
#include "thread.h"
#include "mutex.h"
 
#define NUM_THREADS 5
 
using namespace std;
 
int saldo = 1000;
Mutex mutex;  

int AtualizaSaldo(int n)
{

/*  mutex.lock(); //Bloqueando regiao critica para evitar 
        int meu_saldo = saldo; //lendo saldo
        int novo_saldo = meu_saldo + n*100; // processo de atualização
        saldo = novo_saldo; //atualização
    mutex.unlock();   //Desbloqueando
*/

    mutex.lock(); //Bloqueando regiao critica 
        saldo += n*100; //atualização
        cout << "Novo saldo = " << saldo << endl;
    mutex.unlock();   //Desbloqueando

    return 0;
}
 
int main()
{
    Thread * threads[NUM_THREADS];

    for (int i = 0; i < 5; i++)
    {
        threads[i] = new Thread(&AtualizaSaldo,i);
    }
    for (int i = 0; i < 5; i++)
    {
        threads[i]->join(NULL);
    }
    
 
    cout << "Saldo final é " << saldo << "." << endl;
}



