//1. Criar N threads, uma para somar os valores de cada linha.
//2. Receber o resultado do somatório de cada linha e gerar o somatório total da matriz.
//3. Analise o programa: há problemas de sincronização que precisam ser resolvidos? Se sim, resolva-os.

#include <stdio.h>
#include "thread.h"
#include "mutex.h"


/*
Threads independentes, não geram inconsistência no resultado final,
no entanto os cout's parecem fora de ordem
*/

/* number of matrix columns and rows */
#define M 5
#define N 10

int matrix[N][M];
int sum_total;
Mutex mutex;
  
/* thread function; it sums the values of the matrix in the row */
int SumValues(int i)
{
    mutex.lock();
    int n = (long) i; /* number of row */
    int total = 0; /* the total of the values in the row */
    int j;
    for (j = 0; j < M; j++)          /* sum values in the "n" row */
        total += matrix[n][j];
   
    printf("The total in row %d is %d  \n", n, total);
    mutex.unlock();
    pthread_exit((void**)total);
}

int main(int argc, char *argv[])
{
    Thread * threads[N];
    sum_total = 0;
    int i = 1, j;
    int total = 0; /* the total of the values in the matrix */
    int aux = 0;

    /* initialize the matrix */
    for (i = 0; i < N; i++)
        for (j = 0; j < M; j++)
            matrix[i][j] = i * M + j;
 
    /* create threads */
    for (i = 0; i < N; i++)
    {
        threads[i] = new Thread(&SumValues,i);
    }
    for (i = 0; i < N; i++)
    {
        threads[i]->join(&sum_total);
        aux += sum_total;
    }
    
      
    /* wait for terminate a threads */
    /* COLOQUE SEU CÓDIGO PARA PEGAR O SOMATÓRIO DE LINHAS E TOTALIZAR A SOMA DA MATRIZ AQUI! */
 
     printf("The total values in the matrix is %d \n", aux);
 

    return 0;
}