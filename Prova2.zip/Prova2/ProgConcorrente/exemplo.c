/*
1- O que cada segmento de código apontados como 1,2,3,4 faz?
    1: Este segmento inicializa a chave (key) para a memória compartilhada usada para armazenar os dados (caracteres)
    que o produtor produz e o consumidor consome.
    Em seguida, ele cria a memória compartilhada (usando shmget) com o tamanho de 1024 bytes.
    Ele aloca espaço para o array de caracteres data e o anexa à memória compartilhada (usando shmat).

    2: Este segmento faz o mesmo que o Segmento 1, mas para a memória compartilhada usada para armazenar as flags que
    implementam o algoritmo de exclusão mútua de Peterson. As flags são usadas para garantir que o produtor e o consumidor
    não acessem o mesmo recurso simultaneamente.

    3: O produtor é uma função que produz dados. Ele inicializa as flags de Peterson e, em um loop, coloca dados na memória compartilhada.
    Ele aguarda até que a flag correspondente do consumidor seja falsa e, em seguida, armazena o dado na memória compartilhada.
    Ele também atualiza as flags de Peterson após a conclusão de sua operação.

    4: O consumidor é uma função que consome dados. Ele também inicializa as flags de Peterson e, em um loop, lê dados da memória compartilhada.
    Ele aguarda até que a flag correspondente do produtor seja falsa e, em seguida, lê o dado da memória compartilhada.
    Ele atualiza as flags de Peterson após a conclusão de sua operação.

2- Quais as seções críticas do programa exemplo
    As seções críticas do programa são as partes em que os dados são produzidos e consumidos,
    onde a memória compartilhada é acessada e as flags de Peterson são usadas para garantir a sincronização.

3- Como você iniciaria as flags para sincronizar o programa?
    flags[0] = 1;
    flags[1] = 0;
    flags[3] = 0;
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_SIZE 1024

const int REP = 5;
char dado;
key_t key;
int shmid, flagsid;
char *data;
int *flags;

int producer(int n)
{
    printf("Produtor criado!\n");

    for (int i = 0; i < REP; i++)
    {

        flags[0] = 1;

        while (flags[1] && (flags[3] == 1))
            ;

        data[i] = (char)i + 0x61;           // Parte critica
        printf("Stored... %c \n", data[i]); //

        // Turn esta na posicao 3
        flags[3] = 1;

        flags[0] = 0;
    }

    return n;
}

int consumer(int n)
{
    printf("Consumer was born!\n");

    for (int i = 0; i < REP; i++)
    {

        flags[1] = 1;

        while (flags[0] && (flags[3] == 0))
            ;

        dado = data[i]; // Parte critica
        data[i] = ' ';  //

        printf("Consumed... %c \n", dado);

        flags[3] = 0;

        flags[1] = 0;
    }

    return n;
}

int main()
{
    printf("The Producer x Consumer Problem\n");
    int status;

    key = ftok("/home", 'A');                    //  Segmento
    shmid = shmget(key, 1024, 0644 | IPC_CREAT); //
    data = (malloc(5 * sizeof(char)));           //     1
    data = shmat(shmid, (void *)0, 0);           //

    // Peterson
    key = ftok("/home/downloads", 'B');            //  Segmento
    flagsid = shmget(key, 1024, 0644 | IPC_CREAT); //
    flags = (malloc(3 * sizeof(int)));             //     2
    flags = shmat(flagsid, (void *)0, 0);          //

    flags[0] = 1;
    flags[1] = 0; // Inicializacao das flags
    flags[3] = 0;

    int pid = fork();

    if (pid == 0)
    {
        producer(5);
    }
    else
    {
        consumer(5);

        shmdt(data);                   // Segmento 3  Produtor
        shmctl(shmid, IPC_RMID, NULL); //

        shmdt(flags);                    // Segmento 4  Consumidor
        shmctl(flagsid, IPC_RMID, NULL); //
    }

    return 0;
}
