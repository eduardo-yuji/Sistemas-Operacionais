/*
Exercício 1: Faça um programa utilizando o posix do linux que faça dois processos filhos enviarem mensagem para um mesmo pai por meio de PIPES.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{

    // criando os pipe
    int pp1[2];
    pipe(pp1);

    int pp2[2];
    pipe(pp2);

    // criando o buffer
    char buf1[1024];
    char buf2[1024];

    int pid = fork();

    if (pid == 0)
    { // filho 1
        printf("\nFilho 1");
        write(pp1[1], "Filho1", 6);
    }
    else
    {
        // pai

        pid = fork();

        if (pid == 0)
        { // filho 2
            printf("\nFilho 2");
            write(pp2[1], "Filho2", 6);
        }
        else
        {
            printf("\nPai");
            read(pp1[0], buf1, 1024);
            read(pp2[0], buf2, 1024);
            printf("\nMensagem1: %s", buf1);
            printf("\nMensagem1: %s", buf2);
        }
    }

    return 0;
}