/*
6) Sincronize o código a seguir, de maneira que o processo pai imprima apenas os números impares e o processo filho os números pares. Para isso utilize Semáforos. Utilize memória compartilhada para comunicação entre os processos.
*/

if (fork() != 0)
{ /* I am the parent */
    int i;
    for (i = 0; i < 10; i = i + 2)
    {
        printf("Processo pai %d \n", i);
        sleep(1);
    }
}
else
{ /*Child code */
    int i;
    for (i = 1; i < 10; i = i + 2)
    {
        printf("Processo filho %d \n", i);
    }
}
exit(0);
