/*
5) A partir do exercício 2, retire a solução de Peterson, e responda se é possível sincronizar o programa com apenas 1 (um) único comando. Se sim, aplique esse comando para sincronizar.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <pthread.h>

#define SHM_SIZE 1024

const int REP = 5;
char dado;
key_t key;
int shmid;
char *data;
pthread_mutex_t mutex; // Mutex para garantir a exclusão mútua

int producer(int n)
{
    printf("Producer was born!\n");

    for (int i = 0; i < REP; i++)
    {
        // Bloqueia o acesso ao recurso compartilhado
        pthread_mutex_lock(&mutex);

        data[i] = (char)i + 0x61;
        printf("Stored... %c \n", data[i]);

        // Libera o acesso ao recurso compartilhado
        pthread_mutex_unlock(&mutex);
    }

    return n;
}

int consumer(int n)
{
    printf("Consumer was born!\n");

    for (int i = 0; i < REP; i++)
    // por ser iterativo basta utilizar um wait
    {
        // Bloqueia o acesso ao recurso compartilhado
        pthread_mutex_lock(&mutex);

        dado = data[i];

        data[i] = ' ';

        printf("Consumed... %c \n", dado);

        // Libera o acesso ao recurso compartilhado
        pthread_mutex_unlock(&mutex);
    }

    return n;
}

int main()
{
    printf("The Producer x Consumer Problem\n");
    int status;

    key = ftok("/home", 'A');                    // Segmento
    shmid = shmget(key, 1024, 0644 | IPC_CREAT); //
    data = (malloc(5 * sizeof(char)));           // 1
    data = shmat(shmid, (void *)0, 0);           //

    // Inicializa o mutex
    pthread_mutex_init(&mutex, NULL);

    int pid = fork();

    if (pid == 0)
    {
        // Código do processo pai (consumidor)
        consumer(5);

        shmdt(data);                   // segmento 3
        shmctl(shmid, IPC_RMID, NULL); //

        // Destroi o mutex
        pthread_mutex_destroy(&mutex);
    }
    else
    {
        // Código do processo filho (produtor)
        producer(5);
    }

    return 0;
}
