/*
 Exercício 2: Shared Memory, Complete o código a seguir para que os processos pai e filho possam compartilhar um segmento de memória. O filho escreve no segmento e o pai imprime na tela o conteúdo da mensagem.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(int argc, char *argv[])
{
    key_t key;
    int shmid;
    char *segmento;
    int modo;
    /* Criar a chave: */
    if (key == -1)
    {
        perror("ftok");
        exit(1);
    }
    /*Criar o segmento */
    if (shmid == -1)
    {
        perror("shmget");
        exit(1);
    }
    /*Vincula o segmento de memória á variável segmento*/
    segmento = shmat(shmid, (void *)0, 0);
    if (segmento == (char *)(-1))
    {
        perror("shmat");
        exit(1);
    }

    int pid = fork();
    // Código do filho
    if (pid == 0)
    {
        strcpy(segmento, "OI");
        printf("Filho esta escrevendo na mem comp.\n");
        exit(0);
    }
    else
    {
        wait(NULL);
        printf("Pai esta lendo da mem comp.\n");
        printf("Mensagem: %s", segmento);
    }
    /* Desvincular do segmento */
    if (shmdt(segmento) == -1)
    {
        perror("shmdt");
        exit(1);
    }
    return 0;
}