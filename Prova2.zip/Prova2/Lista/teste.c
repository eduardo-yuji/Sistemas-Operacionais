/*Construa um “pipeline”. Crie um programa que conecte 4 processos através de 3 pipes. Utilize fork() para criar vários processos. Mande uma mensagem do quarto processo e faça a mensagem viajar pelos pipes  até chegar no primeiro processo, e exiba a mensagem.*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main()
{

    int pp1[2];
    pipe(pp1);

    int pp2[2];
    pipe(pp2);

    int pp3[2];
    pipe(pp3);

    char Buffer[1024];

    int pid = fork();

    if (pid == 0)
    { // filho

        pid = fork();

        if (pid == 0)
        { // neto
            pid = fork();

            if (pid == 0)
            {
                printf("Bisneto\n");
            }
            else
            {
                printf("Neto\n");
            }
        }
        else
        {

            printf("Filho\n");
        }
    }
    else
    { // pai
        printf("Pai\n");
    }

    return 0;
}