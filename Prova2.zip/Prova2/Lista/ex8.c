#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <pthread.h>

char *message = "This is a message!!!";
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int main()
{
    int var = 0;

    if (fork() > 0)
    { /* I am the parent */
        var += 5;
        wait(NULL); // Aguarda o término do processo filho
    }
    else
    { /* Child code */
        pthread_mutex_lock(&mutex);
        var += 10;
        pthread_mutex_unlock(&mutex);
    }

    pthread_mutex_lock(&mutex);
    printf("%d", var);
    pthread_mutex_unlock(&mutex);

    return 0;
}
