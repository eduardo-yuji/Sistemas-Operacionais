/*
Exercício 1: Faça um programa utilizando o posix do linux que faça dois processos filhos enviarem mensagem para um mesmo pai por meio de PIPES.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
    // Criando as pontes dos pipes
    int pp1[2];
    pipe(pp1);

    int pp2[2];
    pipe(pp2);

    // Onde a mensagem sera enviada
    char Buf1[1024];
    char Buf2[1024];

    // Criando os processos
    int pid = fork();

    if (pid == 0)
    {
        printf("Sou o primeiro filho\n");
        write(pp1[1], "Sou o favorito do pai\n", 23);
    }
    else
    {
        // pai executando
        pid = fork();
        if (pid == 0)
        {
            printf("Sou o segundo filho\n");
            write(pp2[1], "Nao! Eu quem sou\n", 18);
        }
        else
        {
            printf("Sou o pai\n");
            read(pp1[0], Buf1, 1024);
            read(pp2[0], Buf2, 1024);
            printf("Mensagem recebida do filho 1: %s", Buf1);
            printf("Mensagem recebida do filho 2: %s", Buf2);
        }
    }

    return 0;
}